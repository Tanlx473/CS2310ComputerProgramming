//
//  main.cpp
//  Lab_01_OQ3
//
//  Created by Jeremy Tan on 2025/9/2.
//

#include <iostream>
using namespace std;
int main() {
    char vChar1,vChar2;
    vChar1 = 'B';
    vChar2 = '9';
    cout<<"The values of vChar1 and vChar2: "<<vChar1<<" "<<vChar2<<endl;

    vChar1 = vChar1 - 1;
    
    cout<<"The value of vChar1 now: "<<vChar1<<endl;
    // return 0;
    // OQ1 Part
    
    // OQ2 Part below
    double vFloat1 = 22.0 / 7;
    cout << "The value of vFloat1: " << vFloat1 << endl;
    
    //return 0;
    
    //OQ3 Part below
    cout << "Size of int is " << sizeof(int) << " bytes.\n";
    cout << "Size of char is " << sizeof(char) << " bytes.\n";
    cout << "Size of vFloat1 is " << sizeof(vFloat1) << " bytes.\n" ;
    
    return 0;
    
}

//Output
//The values of vChar1 and vChar2: B 9
//The value of vChar1 now: A
//The value of vFloat1: 3.14286
//Size of int is 4 bytes.
//Size of char is 1 bytes.
//Size of vFloat1 is 8 bytes.
//Program ended with exit code: 0
