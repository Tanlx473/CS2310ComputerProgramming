//
//  main.cpp
//  Lab02_Q1
//
//  Created by Jeremy Tan on 2025/9/9.
//

#include<iostream>
#include<cmath>
using namespace std;
int main() {
double a,b,c;
cin>>a;
cin>>b;
cin>>c;
cout<<"The area is: "<<'\n';
return 0;
}

// No. Because there are not suitable indentation to organise the code to a proper structure.
